package com.example.myetesito.Json;

public class Correo {
    private String MailCorreo;
    private String HTMLCorreo;

    public String getMailCorreo() {
        return MailCorreo;
    }

    public void setMailCorreo(String mailCorreo) {
        MailCorreo = mailCorreo;
    }

    public String getHTMLCorreo() {
        return HTMLCorreo;
    }

    public void setHTMLCorreo(String HTMLCorreo) {
        this.HTMLCorreo = HTMLCorreo;
    }
}
